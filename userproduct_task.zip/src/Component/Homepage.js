import React from 'react'
import Nav from './Nav/Navbar'
import ShowImg from './CategorieItem/ShowImg'
export default function Homepage() {
  return (
    <div>
      <Nav/>
      
    </div>
  )
}
