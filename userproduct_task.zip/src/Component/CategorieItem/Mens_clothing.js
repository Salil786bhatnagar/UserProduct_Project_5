import React from 'react'

export default function Mens_clothing() {
  return (
    <div>Mens_clothing</div>
  )
}
