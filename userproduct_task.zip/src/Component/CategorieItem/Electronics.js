import React from 'react'

export default function Electronics() {
  return (
    <div>Electronics</div>
  )
}
