import React from 'react';
import { BrowserRouter as Router, Route} from 'react-router-dom';
import Homepage from './Component/Homepage';
import Categories from './Component/Categories';
import Jewelery from './Component/CategorieItem/Jewelery';
import Currentpage from './Component/CategorieItem/Currentpage';
import './App.css';
import './Custom.css';
import Search from './Component/CategorieItem/Search';
function App(props) {
  return (
    <div className="App">
     {/* <Homepage/> */}
      <Router>
         <Route 
           path="/"
           component={Homepage}
           exact
           strict
           history={props.history}
         />
         <Route 
           path="/Categories"
           component={Categories}
           exact
           strict
           history={props.history}
         />
          <Route 
           path="/Jewelery"
           component={Jewelery}
           exact
           strict
           history={props.history}
         />
        <Route 
           path="/Currentpage/:id/:category/:price/:rate/:count/:title/:description"
           component={Currentpage}
           exact
           strict
           history={props.history}
         />
          <Route 
           path="/Search"
           component={Search}
           exact
           strict
           history={props.history}
         />
         
      </Router>
    </div>
  );
}

export default App;
